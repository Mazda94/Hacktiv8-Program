/**
 * =======================
 * Will you pass the test?
 * =======================
 * 
 * Description
 * -----------
 * Seorang murid di Sekolah Hacktiv8 ingin mengetahui nilai akhir dari
 * ujian livecode yang dia lakukan 3 kali. Nilai akhir didapat dari rata-rata ketiga nilai
 * livecode dan ditampilkan dalam skala huruf A-E dengan detail sebagai berikut:
 * A -> 80 - 100
 * B -> 70 - 79
 * C -> 60 - 69
 * D -> 50 - 59
 * E -> 0 - 50
 * 
 * Instruction
 * -----------
 * Diketahui nilai murid tersebut adalah 70, 80, dan 90
 * Buatlah pseudocode untuk mencari nilai akhir murid tersebut.
 */

// Write pseudocode here